// All of the js file here uses the ESM module syntax, you can use import instead of require.

import "./dark_mode_controller.js";
import "./full_screen_controller.js";