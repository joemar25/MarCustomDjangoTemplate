// All of the js file here uses the ESM module syntax, you can use import instead of require.

// index.js

import "./htmx_controller.js";
import { themeChange } from 'theme-change'
themeChange()