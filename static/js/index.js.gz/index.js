// All of the js file here uses the ESM module syntax, you can use import instead of require.
import "./settings_controller.js";
import "./htmx_controller.js";
